MODDIR=${0%/*}

chmod 755 $MODDIR/losetup.sh
$MODDIR/losetup.sh  