MODDIR=${0%/*}
export MODDIR=${0%/*}